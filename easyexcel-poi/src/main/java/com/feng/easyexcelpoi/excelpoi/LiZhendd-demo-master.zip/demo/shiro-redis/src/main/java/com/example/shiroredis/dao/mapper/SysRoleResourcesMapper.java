package com.example.shiroredis.dao.mapper;

import com.example.shiroredis.dao.domain.SysRoleResources;
import tk.mybatis.mapper.common.Mapper;

public interface SysRoleResourcesMapper extends Mapper<SysRoleResources> {
}