package com.example.mybatis.model;

import lombok.Data;

/**
 * @author 李振
 * @date 2018/12/21
 */
@Data
public class User {
    private Integer id;
    private String name;
    private String password;
}
