package com.example.mybatisplus.enums;

/**
 *  
 * @author 李振
 * @date 2019/9/27
 */
public enum GenderEnum {
    MALE,
    FEMALE;
}
