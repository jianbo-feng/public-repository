package com.example.shiroredis.dao.mapper;

import com.example.shiroredis.dao.domain.SysUserRole;
import tk.mybatis.mapper.common.Mapper;

public interface SysUserRoleMapper extends Mapper<SysUserRole> {
}