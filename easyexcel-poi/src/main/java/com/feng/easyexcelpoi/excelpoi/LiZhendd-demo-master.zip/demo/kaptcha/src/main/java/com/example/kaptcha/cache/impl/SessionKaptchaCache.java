package com.example.kaptcha.cache.impl;

import com.example.kaptcha.cache.KaptchaCache;
import com.example.kaptcha.cache.config.KaptchaCacheProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import static com.google.code.kaptcha.Constants.KAPTCHA_SESSION_DATE;

/**
 * session 存储实现
 *
 * @author 李振
 * @date 2019/9/28
 */
@Slf4j
public class SessionKaptchaCache implements KaptchaCache {
    @Autowired
    private HttpServletRequest request;

    @Autowired
    private HttpServletResponse response;

    private final KaptchaCacheProperties kaptchaCacheProperties;

    public SessionKaptchaCache(KaptchaCacheProperties kaptchaCacheProperties) {
        this.kaptchaCacheProperties = kaptchaCacheProperties;
    }

    @Override
    public void init(KaptchaCacheProperties kaptchaCacheProperties) {

    }

    @Override
    public void saveKaptcha(String key, String code) {
        HttpSession session = request.getSession();
        session.setAttribute(key, code);
        session.setAttribute(KAPTCHA_SESSION_DATE, System.currentTimeMillis() + kaptchaCacheProperties.getCacheTimeOut());
    }

    @Override
    public String getKaptcha(String key) {
        return (String) request.getSession().getAttribute(key);
    }
}
