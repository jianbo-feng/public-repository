package com.example.javacv;

import com.zihuiinfo.facesdk.common.utils.StringUtils;

import java.lang.reflect.Field;

/**
 * @author 李振
 * @date 2019/10/10
 */
public class Test3 {
    public static void main(String[] args) throws Exception {
        Person aa = new Person(null, "");
        boolean allFieldNull = Test3.isAllFieldNull(aa);
        System.out.println(allFieldNull);
    }

    public static boolean isAllFieldNull(Object obj) throws Exception {
        Class stuCla = obj.getClass();// 得到类对象
        Field[] fs = stuCla.getDeclaredFields();//得到属性集合
        for (Field f : fs) {//遍历属性
            f.setAccessible(true); // 设置属性是可以访问的(私有的也可以)
            Object val = f.get(obj);// 得到此属性的值
            if (val != null) {//只要有1个属性不为空,那么就不是所有的属性值都为空
                if (val instanceof String) {
                    String s = (String) val;
                    if (StringUtils.isNotEmpty(s)) {
                        return false;
                    }
                } else {
                    return false;
                }
            }
        }
        return true;
    }
}

class Person {
    private Integer id;
    private String name;

    public Person(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}