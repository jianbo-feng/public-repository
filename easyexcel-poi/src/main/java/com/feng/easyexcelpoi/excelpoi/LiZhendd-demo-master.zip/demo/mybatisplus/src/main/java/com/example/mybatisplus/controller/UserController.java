package com.example.mybatisplus.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 用户 前端控制器
 * </p>
 *
 * @author lz
 * @since 2019-09-26
 */
@RestController
@RequestMapping("/user")
public class UserController {

}
