# execl
一个简单的execl例子