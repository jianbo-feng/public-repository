package com.example.kaptcha.config;

import lombok.Data;

/**
 * @author 李振
 * @date 2019/9/29
 */
@Data
public class BackgroundColor {

    /**
     * 开始渐变色
     */
    private String from = "lightGray";
    /**
     * 结束渐变色
     */
    private String to = "white";

}