package com.example.kaptcha;

/**
 * @author 李振
 * @date 2019/9/29
 */
public class Test {
    public static void main(String[] args) {
        Package aPackage = Test.class.getPackage();
        System.out.println(Test.class.getName());
    }
}
