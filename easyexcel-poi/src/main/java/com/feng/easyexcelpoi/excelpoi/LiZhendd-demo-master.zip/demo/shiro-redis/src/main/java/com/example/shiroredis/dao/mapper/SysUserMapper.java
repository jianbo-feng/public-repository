package com.example.shiroredis.dao.mapper;

import com.example.shiroredis.dao.domain.SysUser;
import tk.mybatis.mapper.common.Mapper;

public interface SysUserMapper extends Mapper<SysUser> {
}