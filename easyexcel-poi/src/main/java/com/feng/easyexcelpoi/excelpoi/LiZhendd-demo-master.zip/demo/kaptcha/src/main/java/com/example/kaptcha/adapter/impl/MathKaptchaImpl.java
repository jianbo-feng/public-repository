package com.example.kaptcha.adapter.impl;

import com.example.kaptcha.adapter.Kaptcha;
import com.example.kaptcha.cache.KaptchaCache;
import com.example.kaptcha.config.KaptchaProperties;
import com.example.kaptcha.exception.KaptchaNotFoundException;
import com.example.kaptcha.exception.KaptchaTimeoutException;
import com.google.code.kaptcha.impl.DefaultKaptcha;
import org.springframework.util.StringUtils;

import java.awt.image.BufferedImage;

/**
 * 验证码组件实现类
 *
 * @author 李振
 * @date 2019/9/28
 */
public class MathKaptchaImpl implements Kaptcha {
    /**
     * 验证码产生器
     */
    private final DefaultKaptcha kaptcha;
    /**
     * 验证码存储器
     */
    private final KaptchaCache cache;
    /**
     * 验证码配置
     */
    private final KaptchaProperties kaptchaProperties;

    public MathKaptchaImpl(DefaultKaptcha kaptcha, KaptchaCache cache, KaptchaProperties kaptchaProperties) {
        this.kaptcha = kaptcha;
        this.cache = cache;
        this.kaptchaProperties = kaptchaProperties;
    }

    @Override
    public BufferedImage render(String key) {
        String capText = kaptcha.createText();
        String capStr = capText.substring(0, capText.lastIndexOf("@"));
        String code = capText.substring(capText.lastIndexOf("@") + 1);
        cache.saveKaptcha(key, code);
        return kaptcha.createImage(capStr);
    }

    @Override
    public boolean validate(String key, String code) {
        String kaptcha = cache.getKaptcha(key);
        if (StringUtils.isEmpty(kaptcha)) {
            //验证码不存在，已经过期
            throw new KaptchaTimeoutException();
        }

        if (StringUtils.isEmpty(code) || StringUtils.isEmpty(code.trim())) {
            //需要验证的验证码不存在，用户未输入
            throw new KaptchaNotFoundException();
        }

        if (kaptchaProperties.isCaseSensitivity()) {
            //区分大小写
            return kaptcha.equals(code);
        } else {
            //不区分大小写
            return kaptcha.equalsIgnoreCase(code);
        }
    }

}
