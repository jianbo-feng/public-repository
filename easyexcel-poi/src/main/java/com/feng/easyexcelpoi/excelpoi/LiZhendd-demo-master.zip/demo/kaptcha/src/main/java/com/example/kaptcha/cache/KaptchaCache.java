package com.example.kaptcha.cache;

import com.example.kaptcha.cache.config.KaptchaCacheProperties;

/**
 * 保存验证码接口
 *
 * @author 李振
 * @date 2019/9/28
 */
public interface KaptchaCache {
    void init(KaptchaCacheProperties kaptchaCacheProperties);

    /**
     * 保存验证码
     *
     * @param key  验证码key
     * @param code 验证码
     */
    void saveKaptcha(String key, String code);

    /**
     * 获取验证码
     *
     * @param key 验证码key
     * @return 验证码
     */
    String getKaptcha(String key);
}
