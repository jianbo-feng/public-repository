package com.example.validator.framework.validgroup;

/**
 * 更新校验分组
 *
 * @author 李振
 * @date 2019/8/14
 */
public interface UpdateGroup {
}
