package com.example.shiroredissession.dao;

import com.example.shiroredissession.entity.Role;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface RoleDao {

    List<Role> queryRoleList();

    void deleteOneRoleById(Integer id);
}
