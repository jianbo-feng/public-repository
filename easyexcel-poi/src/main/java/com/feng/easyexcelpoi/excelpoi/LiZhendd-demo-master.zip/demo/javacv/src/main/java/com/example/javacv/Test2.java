package com.example.javacv;

import com.zihuiinfo.facesdk.FaceDetectorSDK;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * @author 李振
 * @date 2019/10/9
 */
public class Test2 {


    public static void main(String[] args) {
        List<FaceDetectorSDK> faceDetectorSDKS = new ArrayList<>();
//            List<FaceRecognizerSDK> faceRecognizerSDKS = new ArrayList<>();

        for (int i = 0; i < 100; i++) {
            FaceDetectorSDK faceDetectorSDK = new FaceDetectorSDK();
            faceDetectorSDK.init();
            faceDetectorSDKS.add(faceDetectorSDK);
//                FaceRecognizerSDK faceRecognizerSDK = new FaceRecognizerSDK();
//                faceRecognizerSDK.init();
//                faceRecognizerSDKS.add(faceRecognizerSDK);
        }
        Demo demo = new Demo();
        new Thread(() -> demo.getBatchedImages("E:\\images\\2")).start();

        Thread thread = new Thread(() -> {
            boolean flag = true;
            while (flag) {
                try {
                    BufferedImage batchedImage = demo.getQueue().poll(5L, TimeUnit.SECONDS);
                    if (batchedImage == null) {
                        flag = false;
                        System.out.println("返回为空");
                    }

                    FaceDetectorSDK faceDetectorSDK = faceDetectorSDKS.get(new Random().nextInt(faceDetectorSDKS.size()));
                    faceDetectorSDK.detectFaces(batchedImage);

                    System.out.println("aaaaaaaaaaaaaaaa");
                } catch (Exception e) {
                    e.printStackTrace();
                    flag = false;
                }
            }
            System.out.println("处理完毕");
        });
        thread.start();

        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        for (FaceDetectorSDK faceDetectorSDK : faceDetectorSDKS) {
            faceDetectorSDK.destroy();
        }

//            for (FaceRecognizerSDK faceRecognizerSDK : faceRecognizerSDKS) {
//                faceRecognizerSDK.destroy();
//            }
        System.out.println("...........");
    }


}
