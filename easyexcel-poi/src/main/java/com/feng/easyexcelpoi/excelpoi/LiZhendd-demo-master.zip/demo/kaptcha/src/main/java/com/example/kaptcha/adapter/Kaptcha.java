package com.example.kaptcha.adapter;

import javax.validation.constraints.NotNull;
import java.awt.image.BufferedImage;

/**
 * 验证码产生适配器
 *
 * @author 李振
 * @date 2019/9/28
 */
public interface Kaptcha {

    /**
     * 渲染验证码
     *
     * @return 验证码内容
     */
    BufferedImage render(@NotNull String key);

    /**
     * 校对验证码,默认超时15分钟（900s）
     *
     * @param code 需要验证的字符串
     * @return 是否验证成功
     */
    boolean validate(@NotNull String key, String code);
}
