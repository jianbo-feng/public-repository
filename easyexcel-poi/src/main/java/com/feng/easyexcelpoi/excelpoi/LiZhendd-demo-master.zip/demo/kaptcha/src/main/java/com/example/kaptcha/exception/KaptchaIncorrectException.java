package com.example.kaptcha.exception;

/**
 * @author 李振
 * @date 2019/9/28
 */
public class KaptchaIncorrectException extends KaptchaException {

}
