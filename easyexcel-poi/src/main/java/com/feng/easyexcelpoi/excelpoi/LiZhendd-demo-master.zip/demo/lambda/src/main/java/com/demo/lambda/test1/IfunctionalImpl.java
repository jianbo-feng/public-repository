package com.demo.lambda.test1;

public class IfunctionalImpl implements Ifunctional {
    @Override
    public void method() {
        System.out.println("接口方法的实现！");
    }
}
