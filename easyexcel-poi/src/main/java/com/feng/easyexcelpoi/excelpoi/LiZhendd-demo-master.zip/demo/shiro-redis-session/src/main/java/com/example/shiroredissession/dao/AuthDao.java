package com.example.shiroredissession.dao;

import com.example.shiroredissession.entity.Auth;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface AuthDao {

    List<Auth> queryAuthList();

    void deleteOneAuthById(Integer id);
}
